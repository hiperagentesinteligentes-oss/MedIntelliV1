
import React from 'react'

export const App = () => {
  return (
    <div style={{padding:'2rem', color:'white', background:'#0f172a', minHeight:'100vh'}}>
      <h1>MedIntelliV1 (estrutura mínima)</h1>
      <p>Projeto carregado com sucesso.</p>
    </div>
  )
}
